package com.telecom.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.telecom.base.BaseMapper;
import com.telecom.entity.UserFile2;

@Mapper
public interface UserFile2Mapper extends BaseMapper<UserFile2> {

}

