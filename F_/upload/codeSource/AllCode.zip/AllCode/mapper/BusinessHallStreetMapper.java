package com.telecom.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.telecom.base.BaseMapper;
import com.telecom.entity.BusinessHallStreet;

@Mapper
public interface BusinessHallStreetMapper extends BaseMapper<BusinessHallStreet> {

}

