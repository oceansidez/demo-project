package com.telecom.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.telecom.base.BaseMapper;
import com.telecom.entity.CouponBestPay;

@Mapper
public interface CouponBestPayMapper extends BaseMapper<CouponBestPay> {

}

