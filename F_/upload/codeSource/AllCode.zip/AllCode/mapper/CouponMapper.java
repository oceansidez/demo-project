package com.telecom.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.telecom.base.BaseMapper;
import com.telecom.entity.Coupon;

@Mapper
public interface CouponMapper extends BaseMapper<Coupon> {

}

