package com.telecom.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.telecom.base.BaseMapper;
import com.telecom.entity.CodeSource;

@Mapper
public interface CodeSourceMapper extends BaseMapper<CodeSource> {

}

