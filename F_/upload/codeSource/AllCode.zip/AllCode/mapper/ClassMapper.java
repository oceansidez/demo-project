package com.telecom.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.telecom.base.BaseMapper;
import com.telecom.entity.Class;

@Mapper
public interface ClassMapper extends BaseMapper<Class> {

}

