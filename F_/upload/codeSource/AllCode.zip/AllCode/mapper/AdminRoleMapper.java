package com.telecom.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.telecom.base.BaseMapper;
import com.telecom.entity.AdminRole;

@Mapper
public interface AdminRoleMapper extends BaseMapper<AdminRole> {

}

