package com.telecom.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.telecom.base.BaseMapper;
import com.telecom.entity.Admin;

@Mapper
public interface AdminMapper extends BaseMapper<Admin> {

}

