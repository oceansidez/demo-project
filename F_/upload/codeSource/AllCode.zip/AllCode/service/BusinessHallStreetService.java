package com.telecom.service;

import java.util.List;

import com.telecom.base.BaseService;
import com.telecom.entity.BusinessHallStreet;

public interface BusinessHallStreetService extends BaseService<BusinessHallStreet>{

}

