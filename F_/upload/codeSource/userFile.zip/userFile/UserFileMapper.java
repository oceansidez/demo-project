package com.telecom.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.telecom.base.BaseMapper;
import com.telecom.entity.UserFile;

@Mapper
public interface UserFileMapper extends BaseMapper<UserFile> {

}

